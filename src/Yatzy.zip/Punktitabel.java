public class Punktitabel {
    private String p1_yks = "-";
    private String p1_kaks = "-";
    private String p1_kolm = "-";
    private String p1_neli = "-";
    private String p1_viis = "-";
    private String p1_kuus = "-";
    private String p1_paar = "-";
    private String p1_kakspaar = "-";
    private String p1_kolmik = "-";
    private String p1_nelik = "-";
    private String p1_vrida = "-";
    private String p1_srida = "-";
    private String p1_maja = "-";
    private String p1_chance = "-";
    private String p1_yatzy = "-";
    private String p1_boonus = "-";
    private String p1_vSumma = "-";
    private String p1_sSumma = "-";

    private String p2_yks = "-";
    private String p2_kaks = "-";
    private String p2_kolm = "-";
    private String p2_neli = "-";
    private String p2_viis = "-";
    private String p2_kuus = "-";
    private String p2_paar = "-";
    private String p2_kakspaar = "-";
    private String p2_kolmik = "-";
    private String p2_nelik = "-";
    private String p2_vrida = "-";
    private String p2_srida = "-";
    private String p2_maja = "-";
    private String p2_chance = "-";
    private String p2_yatzy = "-";
    private String p2_boonus = "-";
    private String p2_vSumma = "-";
    private String p2_sSumma = "-";

    public void setP1_yks(int tulemus) {
        p1_vSumma_lisa(tulemus);
        p1_sSumma_lisa(tulemus);
        this.p1_yks = Integer.toString(tulemus);
    }

    public void setP1_kaks(int tulemus) {
        p1_vSumma_lisa(tulemus);
        p1_sSumma_lisa(tulemus);
        this.p1_kaks = Integer.toString(tulemus);
    }

    public void setP1_kolm(int tulemus) {
        p1_vSumma_lisa(tulemus);
        p1_sSumma_lisa(tulemus);
        this.p1_kolm = Integer.toString(tulemus);
    }

    public void setP1_neli(int tulemus) {
        p1_vSumma_lisa(tulemus);
        p1_sSumma_lisa(tulemus);
        this.p1_neli = Integer.toString(tulemus);
    }

    public void setP1_viis(int tulemus) {
        p1_vSumma_lisa(tulemus);
        p1_sSumma_lisa(tulemus);
        this.p1_viis = Integer.toString(tulemus);
    }

    public void setP1_kuus(int tulemus) {
        p1_vSumma_lisa(tulemus);
        p1_sSumma_lisa(tulemus);
        this.p1_kuus = Integer.toString(tulemus);
    }

    public void setP1_paar(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_paar = Integer.toString(tulemus);
    }

    public void setP1_kakspaar(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_kakspaar = Integer.toString(tulemus);
    }

    public void setP1_kolmik(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_kolmik = Integer.toString(tulemus);
    }

    public void setP1_nelik(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_nelik = Integer.toString(tulemus);
    }

    public void setP1_vrida(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_vrida = Integer.toString(tulemus);
    }

    public void setP1_srida(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_srida = Integer.toString(tulemus);
    }

    public void setP1_maja(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_maja = Integer.toString(tulemus);
    }

    public void setP1_chance(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_chance = Integer.toString(tulemus);
    }

    public void setP1_yatzy(int tulemus) {
        p1_sSumma_lisa(tulemus);
        this.p1_yatzy = Integer.toString(tulemus);
    }
    public void setP1_boonus(int tulemus){
        this.p1_boonus = Integer.toString(tulemus) ;
    }

    public void setP2_yks(int tulemus) {
        p2_vSumma_lisa(tulemus);
        p2_sSumma_lisa(tulemus);
        this.p2_yks = Integer.toString(tulemus);
    }

    public void setP2_kaks(int tulemus) {
        p2_vSumma_lisa(tulemus);
        p2_sSumma_lisa(tulemus);
        this.p2_kaks = Integer.toString(tulemus);
    }

    public void setP2_kolm(int tulemus) {
        p2_vSumma_lisa(tulemus);
        p2_sSumma_lisa(tulemus);
        this.p2_kolm = Integer.toString(tulemus);
    }

    public void setP2_neli(int tulemus) {
        p2_vSumma_lisa(tulemus);
        p2_sSumma_lisa(tulemus);
        this.p2_neli = Integer.toString(tulemus);
    }

    public void setP2_viis(int tulemus) {
        p2_vSumma_lisa(tulemus);
        p2_sSumma_lisa(tulemus);
        this.p2_viis = Integer.toString(tulemus);
    }

    public void setP2_kuus(int tulemus) {
        p2_vSumma_lisa(tulemus);
        p2_sSumma_lisa(tulemus);
        this.p2_kuus = Integer.toString(tulemus);
    }

    public void setP2_paar(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_paar = Integer.toString(tulemus);
    }

    public void setP2_kakspaar(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_kakspaar = Integer.toString(tulemus);
    }

    public void setP2_kolmik(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_kolmik = Integer.toString(tulemus);
    }

    public void setP2_nelik(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_nelik = Integer.toString(tulemus);
    }

    public void setP2_vrida(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_vrida = Integer.toString(tulemus);
    }

    public void setP2_srida(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_srida = Integer.toString(tulemus);
    }

    public void setP2_maja(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_maja = Integer.toString(tulemus);
    }

    public void setP2_chance(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_chance = Integer.toString(tulemus);
    }

    public void setP2_yatzy(int tulemus) {
        p2_sSumma_lisa(tulemus);
        this.p2_yatzy = Integer.toString(tulemus);
    }
    public void setP2_boonus(int tulemus){
        this.p2_boonus = Integer.toString(tulemus);
    }

    public void p1_vSumma_lisa(int lisatav) {
        if (p1_vSumma.equals("-")) {
            p1_vSumma = String.valueOf(lisatav);
        } else {
            p1_vSumma = String.valueOf(Integer.valueOf(p1_vSumma) + lisatav);
        }
    }

    public void p1_sSumma_lisa(int lisatav) {
        if (p1_sSumma.equals("-")) {
            p1_sSumma = String.valueOf(lisatav);
        } else {
            p1_sSumma = String.valueOf(Integer.valueOf(p1_sSumma) + lisatav);
        }
    }

    public void p2_vSumma_lisa(int lisatav) {
        if (p2_vSumma.equals("-")) {
            p2_vSumma = String.valueOf(lisatav);
        } else {
            p2_vSumma = String.valueOf(Integer.valueOf(p2_vSumma) + lisatav);
        }
    }

    public void p2_sSumma_lisa(int lisatav) {
        if (p2_sSumma.equals("-")) {
            p2_sSumma = String.valueOf(lisatav);
        } else {
            p2_sSumma = String.valueOf(Integer.valueOf(p2_sSumma) + lisatav);
        }
    }

    public int getP1_yks() {
        if (p1_yks == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_yks);
        }
    }

    public int getP1_kaks() {
        if (p1_kaks == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_kaks);
        }
    }

    public int getP1_kolm() {
        if (p1_kolm == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_kolm);
        }
    }

    public int getP1_neli() {
        if (p1_neli == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_neli);
        }
    }

    public int getP1_viis() {
        if (p1_viis == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_viis);
        }
    }

    public int getP1_kuus() {
        if (p1_kuus == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_kuus);
        }
    }

    public int getP1_paar() {
        if (p1_paar == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_paar);
        }
    }

    public int getP1_kakspaar() {
        if (p1_kakspaar == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_kakspaar);
        }
    }

    public int getP1_kolmik() {
        if (p1_kolmik == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_kolmik);
        }
    }

    public int getP1_nelik() {
        if (p1_nelik == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_nelik);
        }
    }

    public int getP1_vrida() {
        if (p1_vrida == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_vrida);
        }
    }

    public int getP1_srida() {
        if (p1_srida == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_srida);
        }
    }

    public int getP1_maja() {
        if (p1_maja == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_maja);
        }
    }

    public int getP1_chance() {
        if (p1_chance == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_chance);
        }
    }

    public int getP1_yatzy() {
        if (p1_yatzy == "-") {
            return -1;
        } else {
            return Integer.parseInt(p1_yatzy);
        }
    }

    public int getP2_yks() {
        if (p2_yks == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_yks);
        }
    }

    public int getP2_kaks() {
        if (p2_kaks == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_kaks);
        }
    }

    public int getP2_kolm() {
        if (p2_kolm == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_kolm);
        }
    }

    public int getP2_neli() {
        if (p2_neli == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_neli);
        }
    }

    public int getP2_viis() {
        if (p2_viis == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_viis);
        }
    }

    public int getP2_kuus() {
        if (p2_kuus == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_kuus);
        }
    }

    public int getP2_paar() {
        if (p2_paar == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_paar);
        }
    }

    public int getP2_kakspaar() {
        if (p2_kakspaar == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_kakspaar);
        }
    }

    public int getP2_kolmik() {
        if (p2_kolmik == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_kolmik);
        }
    }

    public int getP2_nelik() {
        if (p2_nelik == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_nelik);
        }
    }

    public int getP2_vrida() {
        if (p2_vrida == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_vrida);
        }
    }

    public int getP2_srida() {
        if (p2_srida == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_srida);
        }
    }

    public int getP2_maja() {
        if (p2_maja == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_maja);
        }
    }

    public int getP2_chance() {
        if (p2_chance == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_chance);
        }
    }

    public int getP2_yatzy() {
        if (p2_yatzy == "-") {
            return -1;
        } else {
            return Integer.parseInt(p2_yatzy);
        }
    }

    public int getP1_vSumma() {
        return Integer.parseInt(p1_vSumma);
    }

    public int getP2_vSumma() {
        return Integer.parseInt(p2_vSumma);
    }

    public int getP1_sSumma() {
        return Integer.parseInt(p1_sSumma);
    }

    public int getP2_sSumma() {
        return Integer.parseInt(p2_sSumma);
    }
    public void näitaTabel() {
        System.out.printf("---------------------------------------------------------------------------%n");
        System.out.printf("|                                  YATZY                                  |%n");
        System.out.printf("---------------------------------------------------------------------------%n");
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "KATEGOORIA", "MÄNGIJA 1", "MÄNGIJA 2", "KATEGOORIA", "MÄNGIJA 1", "MÄNGIJA 2");
        System.out.printf("---------------------------------------------------------------------------%n");
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "Üks", p1_yks, p2_yks, "Paar", p1_paar, p2_paar);
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "Kaks", p1_kaks, p2_kaks, "Kaks paari", p1_kakspaar, p2_kakspaar);
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "Kolm", p1_kolm, p2_kolm, "Kolmik", p1_kolmik, p2_kolmik);
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "Neli", p1_neli, p2_neli, "Nelik", p1_nelik, p2_nelik);
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "Viis", p1_viis, p2_viis, "Väike rida", p1_vrida, p2_vrida);
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "Kuus", p1_kuus, p2_kuus, "Suur rida", p1_srida, p2_srida);
        System.out.printf("-------------------------------------| %-10s | %-9s | %-9s |%n", "Maja", p1_maja, p2_maja);
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "SUMMA", p1_vSumma, p2_vSumma, "Chance", p1_chance, p2_chance);
        System.out.printf("| %-10s | %-9s | %-9s | %-10s | %-9s | %-9s |%n", "Boonus", p1_boonus, p2_boonus, "YATZY", p1_yatzy, p2_yatzy);
        System.out.printf("---------------------------------------------------------------------------%n");
        System.out.printf("| %-10s | %-9s | %-9s |                                    |%n", "SUMMA", p1_sSumma, p2_sSumma);
        System.out.printf("---------------------------------------------------------------------------%n");
    }
}